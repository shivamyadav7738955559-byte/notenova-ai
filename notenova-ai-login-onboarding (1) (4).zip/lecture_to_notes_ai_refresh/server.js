require("dotenv").config();
const express = require("express");
const path = require("path");
const dns = require("dns").promises;
const net = require("net");

const app = express();
app.use(express.json({ limit: "5mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/generate", async (req, res) => {
  const { sourceText, mode, difficulty = "Medium" } = req.body || {};
  if (!sourceText || typeof sourceText !== "string" || sourceText.trim().length < 30) {
    return res.status(400).json({ error: "Please provide at least 30 characters of study material." });
  }
  if (!["notes", "flashcards", "quiz", "all"].includes(mode)) {
    return res.status(400).json({ error: "Unknown generation mode." });
  }

  // Demo mode works without an API key. Results are heuristic, not AI-generated.
  if (!process.env.OPENAI_API_KEY) {
    return res.json({ ...demoGenerate(sourceText, mode, difficulty), demo: true });
  }

  try {
    const prompt = `You are a careful college study assistant. Use ONLY the supplied source text. Do not invent facts or numeric data. If the source does not contain values for a graph, create a graph with a note that no numeric data was found and use an empty points array. Return valid JSON only, with these keys and shapes:
notes: {title:string, summary:string, keyPoints:string[], definitions:[{term:string,definition:string}], revisionChecklist:string[]}
flashcards: [{front:string,back:string}]
quiz: [{question:string, options:string[4], answerIndex:number, explanation:string}]
table: {title:string,description:string,columns:string[],rows:string[][]}
graph: {title:string,description:string,points:[{label:string,value:number}],note:string}
slideTitle:string; slides:[{title:string,bullets:string[],speakerNotes:string}]
infographicTitle:string; infographic:[{heading:string,text:string}]
mindmap:{title:string,center:string,branches:[{topic:string,points:string[]}]}
videoTitle:string; video:[{time:string,visual:string,narration:string}]
audio:{title:string,script:string}
Create each output from the supplied source, keeping it accurate and concise. The video output is a storyboard/script, not a rendered video file. The audio output is a narration script. Include only requested resource types where possible, but keep all keys and use empty arrays/objects or null when not requested. For quiz questions, provide exactly four options and one correct answer. Difficulty: ${difficulty}. Requested mode: ${mode}.
SOURCE TEXT:
${sourceText.slice(0, 30000)}`;

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        messages: [
          { role: "system", content: "Return valid JSON only. Do not use markdown fences." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("AI API error:", data);
      return res.status(502).json({ error: data?.error?.message || "AI provider request failed." });
    }
    const content = data.choices?.[0]?.message?.content;
    if (!content) return res.status(502).json({ error: "The AI provider returned an empty response." });
    const parsed = JSON.parse(content);
    return res.json({ ...parsed, demo: false });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Could not generate study material. Check server logs and API configuration." });
  }
});

function demoGenerate(text, mode, difficulty) {
  const clean = text.replace(/\s+/g, " ").trim();
  const sentences = clean.match(/[^.!?]+[.!?]?/g)?.map(s => s.trim()).filter(s => s.length > 20) || [clean];
  const words = clean.split(/\s+/).filter(Boolean);
  const title = words.slice(0, 7).join(" ") + (words.length > 7 ? "…" : "");
  const notes = { title, summary: sentences.slice(0, 3).join(" "), keyPoints: sentences.slice(0, 8).map(s => s.replace(/[.!?]+$/, "")), definitions: [], revisionChecklist: ["Explain the main idea without looking", "Review key terms", "Try the practice quiz"] };
  const flashcards = sentences.slice(0, 10).map((s, i) => ({ front: `What is an important point from section ${i + 1}?`, back: s }));
  const quiz = sentences.slice(0, 5).map((s, i) => ({ question: `Which statement best matches the provided study material (question ${i + 1})?`, options: [s, "This detail is not supported by the provided material.", "The opposite of the statement is always true.", "The material gives no relevant information."], answerIndex: 0, explanation: "Demo mode copies a statement from the supplied material. Add an API key for AI-generated questions." }));
  const tableRows = sentences.slice(0, 8).map((s, i) => [String(i + 1), `Point ${i + 1}`, s]);
  const numeric = [...clean.matchAll(/([A-Za-z][A-Za-z0-9 _-]{1,28})\s*[:=–-]?\s*(\d+(?:\.\d+)?)(%?)/g)].slice(0, 8).map(m => ({ label: m[1].trim(), value: Number(m[2]) }));
  const slides = [{title, bullets: sentences.slice(0, 4), speakerNotes: "Introduce the topic and its main idea."}, ...sentences.slice(4, 12).reduce((acc, sentence, i) => { const idx = Math.floor(i / 3); if (!acc[idx]) acc[idx] = {title: `Key ideas ${idx + 2}`, bullets: [], speakerNotes: "Explain the points and connect them to the main topic."}; acc[idx].bullets.push(sentence); return acc; }, [])].slice(0, 6);
  const output = {
    notes: mode === "flashcards" || mode === "quiz" ? {} : notes,
    flashcards: mode === "notes" || mode === "quiz" ? [] : flashcards,
    quiz: mode === "notes" || mode === "flashcards" ? [] : quiz,
    table: {title: "Extracted study points", description: "Demo table: source statements organized into rows.", columns: ["#", "Type", "Source statement"], rows: tableRows},
    graph: {title: "Values found in source", description: "Only numeric values explicitly detected in the text are charted.", points: numeric, note: numeric.length ? "Demo parser found possible label/value pairs; verify them against the source." : "No clear label-and-number pairs were found in demo mode. Add an AI key for better extraction."},
    slideTitle: title, slides,
    infographicTitle: "Topic at a glance", infographic: sentences.slice(0, 6).map((s, i) => ({heading: `Key idea ${i + 1}`, text: s})),
    mindmap: {title: "Topic mind map", center: title, branches: sentences.slice(0, 6).map((s, i) => ({topic: `Idea ${i + 1}`, points: [s]}))},
    videoTitle: `${title} — video overview`, video: sentences.slice(0, 5).map((s, i) => ({time: `00:${String(i * 12).padStart(2, "0")}`, visual: i === 0 ? "Title card and topic introduction" : `Scene ${i + 1}: illustrate the key point`, narration: s})),
    audio: {title: `${title} — audio overview`, script: `Here is a quick overview. ${sentences.slice(0, 6).join(" ")}`},
    demo: true,
    notice: "Demo mode: these are heuristic examples, not genuine AI-generated visuals. Add OPENAI_API_KEY to .env for full AI-generated resources. Audio uses browser speech; video is a storyboard."
  };
  return output;
}

function isPrivateAddress(address) {
  if (net.isIPv4(address)) {
    const p = address.split(".").map(Number);
    return p[0] === 10 || p[0] === 127 || p[0] === 0 || (p[0] === 169 && p[1] === 254) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31) || (p[0] === 192 && p[1] === 168) || p[0] >= 224;
  }
  if (net.isIPv6(address)) return address === "::1" || address === "::" || /^f[cd]/i.test(address) || /^fe[89ab]/i.test(address) || address.startsWith("::ffff:127.");
  return true;
}

app.post("/api/import-url", async (req, res) => {
  const raw = req.body?.url;
  let url;
  try { url = new URL(raw); } catch { return res.status(400).json({error:"Enter a valid public URL."}); }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) return res.status(400).json({error:"Only public HTTP or HTTPS links are supported."});
  if (["localhost", "localhost.localdomain"].includes(url.hostname) || url.hostname.endsWith(".local")) return res.status(400).json({error:"Private/local links cannot be imported."});
  try {
    const addresses = net.isIP(url.hostname) ? [{address:url.hostname}] : await dns.lookup(url.hostname, {all:true});
    if (!addresses.length || addresses.some(a => isPrivateAddress(a.address))) return res.status(400).json({error:"This link does not resolve to a public host."});
    const response = await fetch(url, {headers:{"User-Agent":"NoteNovaAI-StudyImporter/1.0","Accept":"text/html,text/plain,text/markdown,application/pdf;q=0.8"}, redirect:"manual", signal:AbortSignal.timeout(12000)});
    if (response.status >= 300 && response.status < 400) return res.status(400).json({error:"This link redirects. Open the final public URL and try again."});
    if (!response.ok) return res.status(502).json({error:`The website returned ${response.status}.`});
    const type = response.headers.get("content-type") || "";
    if (!/text\/(html|plain|markdown)/i.test(type)) return res.status(415).json({error:"This link is not a readable webpage or text file."});
    const declared = Number(response.headers.get("content-length") || 0);
    if (declared > 2_000_000) return res.status(413).json({error:"This source is too large. Use a smaller file."});
    let body = await response.text();
    if (body.length > 2_000_000) body = body.slice(0, 2_000_000);
    if (/text\/html/i.test(type)) body = body.replace(/<(script|style|noscript|svg)[^>]*>[\s\S]*?<\/\1>/gi, " ").replace(/<(br|\/p|\/div|\/li|\/h[1-6])\b[^>]*>/gi, "\n").replace(/<[^>]+>/g, " ").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&#39;/gi, "'").replace(/&quot;/gi, '"').replace(/\s+/g, " ").trim();
    if (body.length < 30) return res.status(422).json({error:"Not enough readable text found. Try copying the webpage text or uploading a file."});
    res.json({title:url.hostname, text:body.slice(0, 30000)});
  } catch (err) {
    console.error("URL import error:", err.message);
    res.status(502).json({error:"Could not import this link. It may be private, blocked, or unsupported."});
  }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`NoteNova AI running at http://localhost:${port}`));
