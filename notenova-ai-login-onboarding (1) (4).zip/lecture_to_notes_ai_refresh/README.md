# NoteNova AI

A dark-mode, responsive study-assistant starter project for college students.

## Features
- Responsive dark dashboard
- Subject, semester, and chapter fields
- PDF text extraction in the browser (text-based PDFs; scanned PDFs need OCR)
- TXT and Markdown import
- Notes, flashcards, MCQs, data tables, and graph generation interface
- Slide-deck outline with print / save as PDF
- Infographic summary and mind-map views
- Video storyboard and downloadable narration script
- Audio overview using browser text-to-speech
- Sidebar New chat button and keyboard shortcut (Ctrl/Cmd + K)
- Composer + menu for file upload, website URL, public Drive link, and clipboard text
- Public webpage text import with basic private-network URL checks
- Flashcard flip and navigation
- Quiz submission, scoring, and explanations
- Save study kits to browser local storage
- Export saved library as JSON
- Demo mode works without an AI key
- Optional server-side OpenAI API integration

## Requirements
- Node.js 18+
- Internet access for PDF.js CDN and optional AI API

## Run locally
1. Extract the ZIP.
2. Open a terminal in the project folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Optional: add your API key to `OPENAI_API_KEY` in `.env`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

Without an API key, the app uses a simple demo generator. This proves the interface and interactions work, but demo results are not genuine AI-generated study material. With an API key, generation calls the configured OpenAI-compatible Chat Completions endpoint from the server. Slide decks can be printed or saved as PDF. The audio overview uses browser speech synthesis and does not create an MP3. Video output is a storyboard/script, not a rendered video file. Website and Drive imports work only when the linked content is public and readable; private Google Drive files require a real Google Drive OAuth integration, which is not included.

## Security notes
- Never place API keys in `public/index.html`.
- Do not commit `.env` to source control.
- Add authentication, rate limiting, upload limits, privacy controls, and server-side persistence before a public launch.
- This starter stores saved kits and quiz attempts in the current browser only. It does not yet have user accounts or cross-device sync.
- Check your AI provider's pricing and data policies before using real student documents.



## Domain setup
The app branding uses **NoteNova AI**. To use `notenova.com` publicly, register/own the domain and configure DNS plus hosting to point to your deployed server. The local development address remains `http://localhost:3000`.
